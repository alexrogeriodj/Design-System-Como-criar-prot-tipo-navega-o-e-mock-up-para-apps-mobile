// const getJS = () => (
// 	fs.readFileSync(path.normalize(`${__dirname}/docs/js/script.js`), 'utf8')
// )

// const addScripts = ({ document }) => {
// 	const scriptTag = document.createElement('script');
// 	scriptTag.innerHTML = getJS();
// 	document.querySelector('body').appendChild(scriptTag);
// }

// module.exports = addScripts;
